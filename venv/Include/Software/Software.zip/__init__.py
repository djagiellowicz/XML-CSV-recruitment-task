import myFunctions

myFunctions.joinXMLWithCSV('products.xml', 'prices.csv')
















